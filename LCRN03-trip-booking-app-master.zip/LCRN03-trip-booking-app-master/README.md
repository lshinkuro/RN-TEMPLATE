# LCRN03 - Trip Booking App

## [Watch it on YouTube](https://youtu.be/iVT7DRw2e7g)

In this episode of "Let’s Code React Native" series, we are going to build a beautiful Trip Booking app based on the design created by Reiza on Dribbble.

Be sure to subscribe to our YouTube channel for more videos like this!

## Table of Contents

| Code | Project | Preview | Inspiration | No. of Screens |
| ------ | ------ | ------ | ------ | ------ |
| LCRN03 | [Trip Booking App](https://youtu.be/iVT7DRw2e7g) | <img src="https://static.dribbble.com/users/2232922/screenshots/13988973/media/ddba1ee5e948bd07a87136b7bdde48b9.png?compress=1&resize=1200x900" width="120" /> | [View](https://dribbble.com/shots/13988973-Digitalz-Ticket) | 3 |

## Contributors

<a href="https://github.com/byprogrammers/LCRN03-trip-booking-app/graphs/contributors">
   <img src="https://contrib.rocks/image?repo=byprogrammers/lets-code-react-native" />
</a>

