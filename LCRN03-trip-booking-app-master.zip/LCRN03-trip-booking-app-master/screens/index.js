import Onboarding from "./Onboarding";
import Home from "./Home";
import DestinationDetail from "./DestinationDetail";

export {
    Onboarding,
    Home,
    DestinationDetail
};
