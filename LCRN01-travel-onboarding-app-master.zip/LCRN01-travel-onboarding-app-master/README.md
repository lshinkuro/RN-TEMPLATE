# Travel Onboarding App

## [Watch it on YouTube](https://youtu.be/1XP28xVToho)

In this very first episode of "Let’s Code React Native" series, we are going to build a beautiful scrollable onboarding screen based on the design created by Dulanjaya on Uplabs. 

Be sure to subscribe to our YouTube channel for more videos like this!

## Table of Contents

| Code | Project | Preview | Inspiration | No. of Screens |
| ------ | ------ | ------ | ------ | ------ |
| LCRN01 | [Travel Onboarding App](https://youtu.be/1XP28xVToho) | <img src="https://i.ibb.co/pPNyYFP/preview.png" width="120" />  | [View](https://www.uplabs.com/posts/splash-screen-mobile-ui-5) | 1 |

## Contributors

<a href="https://github.com/byprogrammers/LCRN01-travel-onboarding-app/graphs/contributors">
   <img src="https://contrib.rocks/image?repo=byprogrammers/lets-code-react-native" />
</a>

