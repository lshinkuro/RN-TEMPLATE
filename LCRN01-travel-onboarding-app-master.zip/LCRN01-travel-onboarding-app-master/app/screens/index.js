// Onboarding screen
import OnBoarding from "./OnBoarding/OnBoarding";

export {
    OnBoarding,
};
