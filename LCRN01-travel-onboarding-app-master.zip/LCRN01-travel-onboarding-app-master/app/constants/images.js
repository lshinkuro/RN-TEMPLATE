export const onboarding1 = require("../assets/images/onboarding-1.png");
export const onboarding2 = require("../assets/images/onboarding-2.png");
export const onboarding3 = require("../assets/images/onboarding-3.png");

export default {
  onboarding1,
  onboarding2,
  onboarding3
}